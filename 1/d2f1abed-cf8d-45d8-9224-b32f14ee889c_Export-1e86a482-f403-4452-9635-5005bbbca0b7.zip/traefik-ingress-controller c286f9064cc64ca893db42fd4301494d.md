# traefik-ingress-controller

Created: November 3, 2023 5:23 PM
Tags: kubernetes
Backgroud: traefik-ingress-controller%20c286f9064cc64ca893db42fd4301494d/traefik.png
Sub-item: traefik使用 (https://www.notion.so/traefik-35fd55a5b8494867b30c9833244909c8?pvs=21)

# Traefik部署篇

### 1、helm安装traefik

```bash
# 添加traefik的chart源
helm repo add traefik https://traefik.github.io/charts
# 更新源
helm repo update
# 拉取traefik的chart文件
helm fetch traefik traefik/traefik
# 解压
tar xf traefik-25.0.0.tgz 
```

### 2、自定义value值部署traefik

本地部署的kubernetes集群没有云厂商的loadBalancer，需要借助于k8s集群节点的端口去映射traefik的web端口

- 使用k8s节点的主机网络

```yaml
hostNetwork: true
```

- 端口部分修改（基于hostNetwork: true的情况修改）

```yaml
ports:
  traefik:  #  dashboard的端口暴露
    port: 9000  
    expose: true
    exposedPort: 9000
    protocol: TCP
  web:   # traefik的web业务端口
    port: 80
    # hostPort: 80
    expose: true
    exposedPort: 80
    protocol: TCP
  websecure: # 443端口 tls
    port: 443
    expose: true
    exposedPort: 443
    protocol: TCP
    http3:
      enabled: false
    tls:
      enabled: true
      options: ""
      certResolver: ""
      domains: []
    middlewares: []
  metrics: # 指标暴露端口，默认端口为9100，与prometheus的node_exporter的端口一样，起冲突会到Pod无法启动，建议修改
    port: 9600
    expose: false
    exposedPort: 9600
    protocol: TCP
```

- 端口绑定的安全机制（需要用到80和443端口，1024以下的端口只允许root用户使用）

```yaml
securityContext:
  capabilities:
		drop: [ALL] # 去掉了root下的各种特权
    add: [NET_BIND_SERVICE] # 单独释放程序运行网络绑定的能力
  readOnlyRootFilesystem: true # 只读访问根文件系统 true为允许
  runAsGroup: 0
	runAsNonRoot: false # 禁止容器使用root身份运行，true为禁止，false则运行使用root
  runAsUser: 0
```

### 3、使用自定的values.yaml文件进行部署

```bash
helm install -f values.yaml traefik traefik/traefik
```